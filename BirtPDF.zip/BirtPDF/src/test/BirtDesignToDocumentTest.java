package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BirtDesignToDocumentTest {

	@Test
	void testBirtDesignToDocument() {
		fail("Not yet implemented");
	}

	@Test
	void testGenerateDocument() {
		fail("Not yet implemented");
	}

	@Test
	void testGeneratePDF() {
		fail("Not yet implemented");
	}

	@Test
	void testGenerateDOC() {
		fail("Not yet implemented");
	}

	@Test
	void testGenerateXLSX() {
		fail("Not yet implemented");
	}

	@Test
	void testGenerateHTML() {
		fail("Not yet implemented");
	}

}
