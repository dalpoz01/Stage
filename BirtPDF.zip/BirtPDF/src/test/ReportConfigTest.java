package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ReportConfigTest {

	@Test
	void testReportConfig() {
		fail("Not yet implemented");
	}

	@Test
	void testGetJsonSource() {
		fail("Not yet implemented");
	}

	@Test
	void testSetJsonSource() {
		fail("Not yet implemented");
	}

	@Test
	void testGetBirtFilePath() {
		fail("Not yet implemented");
	}

	@Test
	void testSetBirtFilePath() {
		fail("Not yet implemented");
	}

	@Test
	void testGetOutputFormat() {
		fail("Not yet implemented");
	}

	@Test
	void testSetOutputFormat() {
		fail("Not yet implemented");
	}

	@Test
	void testGetJsonSourceType() {
		fail("Not yet implemented");
	}

	@Test
	void testSetJsonSourceType() {
		fail("Not yet implemented");
	}

	@Test
	void testIsValidConfig() {
		fail("Not yet implemented");
	}

	@Test
	void testIsApiSource() {
		fail("Not yet implemented");
	}

}
