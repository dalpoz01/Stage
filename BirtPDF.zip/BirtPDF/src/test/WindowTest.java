package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class WindowTest {

	@Test
	void testWindow() {
		fail("Not yet implemented");
	}

	@Test
	void testCreateLoadingDialog() {
		fail("Not yet implemented");
	}

	@Test
	void testShowSuccessDialog() {
		fail("Not yet implemented");
	}

	@Test
	void testShowErrorDialog() {
		fail("Not yet implemented");
	}

	@Test
	void testGetFrame() {
		fail("Not yet implemented");
	}

	@Test
	void testGetTextField_JsonFile() {
		fail("Not yet implemented");
	}

	@Test
	void testGetTextField_BirtFile() {
		fail("Not yet implemented");
	}

	@Test
	void testGetBtnLoadBirt() {
		fail("Not yet implemented");
	}

	@Test
	void testGetBtnLoadJson() {
		fail("Not yet implemented");
	}

	@Test
	void testGetBtnGeneratePDF() {
		fail("Not yet implemented");
	}

	@Test
	void testGetComboBox_Formato() {
		fail("Not yet implemented");
	}

	@Test
	void testGetComboBox_JsonType() {
		fail("Not yet implemented");
	}

}
